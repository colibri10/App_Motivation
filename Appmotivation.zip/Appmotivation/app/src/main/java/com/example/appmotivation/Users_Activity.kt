package com.example.appmotivation

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Users_Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_users)

        val nomeEditText = findViewById<EditText>(R.id.nome)
        val botaoSalvar = findViewById<Button>(R.id.botao)

        botaoSalvar.setOnClickListener {
            val nomeDigitado = nomeEditText.text.toString().trim()

            if (nomeDigitado.isNotEmpty()) {
                // Cria o Intent e envia o nome
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("nome_usuario", nomeDigitado)
                startActivity(intent)
                finish() // fecha esta activity
            } else {
                nomeEditText.error = "Digite seu nome!"
            }
        }

    }
}