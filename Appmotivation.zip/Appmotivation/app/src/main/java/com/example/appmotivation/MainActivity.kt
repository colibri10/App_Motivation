package com.example.appmotivation

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        val fraseRepository = FraseRepository()

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nomeTextView = findViewById<TextView>(R.id.nome)
        val nomeRecebido = intent.getStringExtra("nome_usuario")
        if (!nomeRecebido.isNullOrEmpty()) {
            nomeTextView.text = "Olá, $nomeRecebido"
        }

        val btnVoltar = findViewById<Button>(R.id.btnVoltar)
        btnVoltar.setOnClickListener {
            val intent = Intent(this, Users_Activity::class.java)
            startActivity(intent)
            finish() // fecha a atual depois de abrir a inicial
        }

        val novaFrase = findViewById<TextView>(R.id.text)
        val botaoFrase = findViewById<Button>(R.id.bot)
        val imagemAll = findViewById<ImageView>(R.id.inf)
        val imagemHappy = findViewById<ImageView>(R.id.smile)
        val imagemSun = findViewById<ImageView>(R.id.solz)

        imagemAll.setOnClickListener {
            imagemAll.setColorFilter(ContextCompat.getColor(this, R.color.white))
            imagemHappy.setColorFilter(ContextCompat.getColor(this, R.color.black))
            imagemSun.setColorFilter(ContextCompat.getColor(this, R.color.black))
            val fraseSorteada = fraseRepository.getFrase(0)
            novaFrase.text = fraseSorteada
        }

        imagemHappy.setOnClickListener {
            imagemHappy.setColorFilter(ContextCompat.getColor(this, R.color.white))
            imagemAll.setColorFilter(ContextCompat.getColor(this, R.color.black))
            imagemSun.setColorFilter(ContextCompat.getColor(this, R.color.black))
            val fraseSorteada = fraseRepository.getFrase(1)
            novaFrase.text = fraseSorteada
        }

        imagemSun.setOnClickListener {
            imagemSun.setColorFilter(ContextCompat.getColor(this, R.color.white))
            imagemAll.setColorFilter(ContextCompat.getColor(this, R.color.black))
            imagemHappy.setColorFilter(ContextCompat.getColor(this, R.color.black))
            val fraseSorteada = fraseRepository.getFrase(2)
            novaFrase.text = fraseSorteada
        }

        botaoFrase.setOnClickListener {
            val fraseSorteada = fraseRepository.getFrase(0)
            novaFrase.text = fraseSorteada
        }
    }
}
